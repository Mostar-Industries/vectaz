
import DecisionMatrix from './DecisionMatrix';

export { DecisionMatrix };
export default DecisionMatrix;
