
// Export the refactored DecisionMatrix component from its new location
export { default as DecisionMatrix } from './decision-matrix/DecisionMatrix';
