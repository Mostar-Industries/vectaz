
# decision_snapshot_logger.py – Writes every decision event to JSONL for audit trail

import json
from datetime import datetime
from pathlib import Path
from typing import Dict

LOG_PATH = Path("logs/decision_log.jsonl")
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

def log_decision_event(data: Dict):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        **data
    }
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")
